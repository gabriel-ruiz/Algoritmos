/**
 * Esta interfaz tambien podria ser una clase abstracta.
 * @author: Skyvortex Solutions
 */
public interface Factory{
	public abstract void methodOne();
	
	public abstract void methodTwo();
}
