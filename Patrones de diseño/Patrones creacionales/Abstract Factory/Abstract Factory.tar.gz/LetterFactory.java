public class LetterFactory extends Factory{
	public void printSymbol(){
		System.out.println("A");
	}
}
