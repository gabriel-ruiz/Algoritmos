public class NumberFactory extends Factory{
	public void printSymbol(){
		System.out.println("1");
	}
}
