public abstract class Factory{
	public void printRareSymbol(){
		System.out.println("%");	
	}
	
	public abstract void printSymbol();
}
