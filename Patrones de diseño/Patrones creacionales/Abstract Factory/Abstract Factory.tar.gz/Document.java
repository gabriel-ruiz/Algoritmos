public abstract class Document{
	public abstract void printPhrase();
	
	public abstract Factory getFactory();
}
